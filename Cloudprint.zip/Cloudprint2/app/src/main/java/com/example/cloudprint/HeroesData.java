package com.example.cloudprint;

import java.util.ArrayList;
import java.util.Collection;

public class HeroesData {
    private static String[] heroNames = {
            "PRINTER CENTRE - IZZILOW",
            "ASLAM Printer Malang",
            "CucuShinta PRINT - Servis printer",
            "MB Print",
            "Ijen Computer",
            "Tujuh Komputer",
            "GASOL COMPUTER MALANG",
            "Majesty Printing",
            "Soepomo",
            "Tan Malaka"
    };

    private static String[] heroDetails = {
            "Jl. Permata Hijau.G No.113, Tlogomas, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144",
            "Jl. Sigura - Gura Barat No.20, Karangbesuki, Kec. Sukun, Kota Malang, Jawa Timur 65149",
            "Jl. MT. Haryono Gg. II No.482, Dinoyo, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144",
            "Jl. Gajayana No.796, Dinoyo, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144",
            "Jl. Besar Ijen No.77B, Oro-oro Dowo, Kec. Klojen, Kota Malang, Jawa Timur 65119",
            "Jl. Gajayana No.544, Dinoyo, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144",
            "Jl. Raya Tlogomas No.1, Tlogomas, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144",
            "Jl. Brigjend Slamet Riadi No.44, Oro-oro Dowo, Kec. Klojen, Kota Malang, Jawa Timur 65112",
            "Prof. Mr. Dr. Soepomo (Ejaan Soewandi: Supomo; lahir di Sukoharjo, Jawa Tengah, 22 Januari 1903 – meninggal di Jakarta, 12 September 1958 pada umur 55 tahun) adalah seorang pahlawan nasional Indonesia. Soepomo dikenal sebagai arsitek Undang-undang Dasar 1945, bersama dengan Muhammad Yamin dan Soekarno.",
            "Tan Malaka atau Ibrahim gelar Datuk Sutan Malaka (lahir di Nagari Pandam Gadang, Suliki, Lima Puluh Kota, Sumatera Barat, 2 Juni 1897 – meninggal di Desa Selopanggung, Kediri, Jawa Timur, 21 Februari 1949 pada umur 51 tahun) adalah seorang pembela kemerdekaan Indonesia, tokoh Partai Komunis Indonesia, juga pendiri Partai Murba, dan merupakan salah satu Pahlawan Nasional Indonesia."
    };

    private static int[] heroesImages = {
            R.drawable.ahmad_dahlan,
            R.drawable.ahmad_yani,
            R.drawable.bung_tomo,
            R.drawable.gatot_subroto,
            R.drawable.ki_hadjar_dewantara,
            R.drawable.mohammad_hatta,
            R.drawable.sudirman,
            R.drawable.sukarno,
            R.drawable.supomo,
            R.drawable.tan_malaka
    };


    static Collection<? extends Hero> getListData() {
        ArrayList<Hero> list = new ArrayList<>();
        for (int position = 0; position < heroNames.length; position++) {
            Hero hero = new Hero();
            hero.setName(heroNames[position]);
            hero.setDetail(heroDetails[position]);
            hero.setPhoto(heroesImages[position]);
            list.add(hero);
        }
        return list;
    }

}
